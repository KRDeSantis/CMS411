import docx2txt



def getText(filename):
    doc = docx2txt.process(filename)
    print(doc)
    #fullText = []
    #for para in doc.paragraphs:
    #fullText.append(para.text)
    #return '\n'.join(fullText)

def test():
    getText('test1.docx')
    return

test()
